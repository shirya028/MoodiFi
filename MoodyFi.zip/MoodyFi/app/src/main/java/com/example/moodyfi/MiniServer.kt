package com.example.moodyfi

import android.content.ContentResolver
import android.content.Context
import android.provider.MediaStore

class MiniServer(private val context: Context) {

    fun findSongPathByTitle(songTitle: String): String? {
        val contentResolver: ContentResolver = context.contentResolver
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media.DATA
        )

        val selection = "${MediaStore.Audio.Media.TITLE}=?"
        val selectionArgs = arrayOf(songTitle)
        val sortOrder = null

        contentResolver.query(uri, projection, selection, selectionArgs, sortOrder)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val columnIndex = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                return cursor.getString(columnIndex)
            }
        }
        return null
    }
}