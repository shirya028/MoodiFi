package com.example.moodyfi

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import kotlinx.coroutines.delay

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installSplashScreen()
        Thread.sleep(3000)
        setContentView(R.layout.activity_main)

        //check kr ki permission dily ki ny
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED)
        {
            //if dilay go to main page
            val i1=Intent(this,MainPage::class.java)
            startActivity(i1);
        }
        else
        {
            //premision handling.....recursively
            val grantBtn=findViewById<Button>(R.id.grantBtn)
            grantBtn.setOnClickListener {
                checkPermission()
            }

        }
    }

    override fun onResume() {
        super.onResume()
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED)
        {
            //if dilay go to main page
            val i1=Intent(this,MainPage::class.java)
            startActivity(i1);
        }
    }
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode==0 && grantResults.isNotEmpty()) {
            for(i in grantResults.indices) {
                if(grantResults[i] ==PackageManager.PERMISSION_GRANTED )
                {
                    val i1=Intent(this,MainPage::class.java)
                    startActivity(i1);
                }
            }
        }
    }
    private  fun checkPermission() {

        val sharedPref = applicationContext.getSharedPreferences("my_preferences", Context.MODE_PRIVATE)
        val editor =sharedPref.edit()

        val count=sharedPref.getInt("countValue",0);
        if(count<2)
        {
            if(ActivityCompat.checkSelfPermission(this,Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED)
            {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE),0)
            }

            editor.putInt("countValue",count+1)
            editor.apply()
        }
        else
        {
            Toast.makeText(this,"You need to grant permission", Toast.LENGTH_SHORT).show()

            val dialog=AlertDialog.Builder(this)
                                .setTitle("App permission required !")
                                .setMessage("You need to grant permission from app setting")
                                .setIcon(R.drawable.audio_file)
                                .setPositiveButton("Grant") { _ ,_ ->

                                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                    val uri = Uri.fromParts("package", packageName, null)
                                    intent.data = uri
                                    startActivity(intent)
                                }
                                .setNegativeButton("Decline") { _ ,_ ->
                                    Toast.makeText(this,"Its mandatory to give permission",Toast.LENGTH_SHORT).show()
                                }
                                .create()
                                .show()
        }

    }
}