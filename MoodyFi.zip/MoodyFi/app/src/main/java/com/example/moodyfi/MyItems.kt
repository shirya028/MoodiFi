package com.example.melodyhub

data class MyItems(var title:String,var artist: String)
