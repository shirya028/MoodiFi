package com.example.moodyfi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.example.melodyhub.All_Music_page
import com.example.melodyhub.home_page
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_page)
        var homeFragment= home_page()
        var AllMusic= All_Music_page()

        setCurrentFragment(homeFragment)

        var bottomNavigationView=findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener {

            when(it.itemId) {
                R.id.myhome -> setCurrentFragment(homeFragment)
                R.id.mymusic -> setCurrentFragment(AllMusic)
                R.id.myplaylist -> setCurrentFragment(homeFragment)
            }
            true

        }

    }

    private fun setCurrentFragment(fragment: Fragment) =
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.fl_id,fragment)
            commit()
        }


}