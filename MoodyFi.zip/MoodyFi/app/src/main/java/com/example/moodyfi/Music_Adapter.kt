package com.example.melodyhub

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.moodyfi.R

class Music_Adapter(var songs:List<MyItems>):RecyclerView.Adapter<Music_Adapter.myAdapterViewHolder>()
{
    inner class myAdapterViewHolder(itemView: View, listner:onItemClickListener):RecyclerView.ViewHolder(itemView)
    {
        init {
            itemView.setOnClickListener {
                listner.onItemClick(adapterPosition)
            }
        }
    }

    private lateinit var myListener:onItemClickListener
    interface onItemClickListener{
        fun onItemClick(position: Int)
    }
    fun setOnItemClickListener(listener: onItemClickListener)
    {
        myListener=listener
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): myAdapterViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_design,parent,false)
        return myAdapterViewHolder(view,myListener)
    }

    override fun getItemCount(): Int {

        return songs.size
    }

    override fun onBindViewHolder(holder: myAdapterViewHolder, position: Int) {

        holder.itemView.apply {
            var t1=findViewById<TextView>(R.id.t1)
            var t2=findViewById<TextView>(R.id.t2)
            t1.text=songs[position].title
            t2.text=songs[position].artist

        }
    }

}