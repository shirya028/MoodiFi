package com.example.melodyhub

import androidx.fragment.app.Fragment
import com.example.moodyfi.R


class home_page : Fragment(R.layout.fragment_home_page) {


}