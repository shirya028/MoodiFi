package com.example.melodyhub

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.widget.SearchView;
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.moodyfi.MainActivity
import com.example.moodyfi.MiniServer
import com.example.moodyfi.R
import com.example.moodyfi.music_player
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale

class All_Music_page : Fragment() {

   private fun requestPermission(view: View) {
      if (ActivityCompat.checkSelfPermission(
            view.context,
            Manifest.permission.READ_EXTERNAL_STORAGE
         ) != PackageManager.PERMISSION_GRANTED
      ) {
            var i1 = Intent(view.context as Activity, MainActivity::class.java)
            startActivity(i1);

      }
   }
   override fun onCreateView(
      inflater: LayoutInflater, container: ViewGroup?,
      savedInstanceState: Bundle?
   ): View? {

      val view = inflater.inflate(R.layout.fragment_all__music_page, container, false)
      val server=MiniServer(view.context)
      requestPermission(view)
      val selection=MediaStore.Audio.Media.IS_MUSIC+"!=0"
      val projection= arrayOf( MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
      val sortOrder="${MediaStore.Audio.Media.TITLE} ASC"

      val activity=requireActivity();
      val cursor = activity.contentResolver.query(
         MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
         projection,
         selection,
         null,
         sortOrder
      );


      var dataList= mutableListOf<MyItems>()
      var musicList= mutableListOf<String>()
      cursor?.use {
         while (it.moveToNext())
         {
            val titleIndex = it.getColumnIndex(MediaStore.Audio.Media.TITLE)
            val artistIndex = it.getColumnIndex(MediaStore.Audio.Media.ARTIST)


            var titleNm=if(titleIndex!=-1 && !it.isNull(titleIndex))
            {
               it.getString(titleIndex)

            }
            else{
               " "
            }
            musicList.add(titleNm)
            var titleArti=if(titleIndex!=-1 && !it.isNull(titleIndex))
            {
               it.getString(artistIndex)
            }
            else{
               " "
            }

            dataList.add(MyItems(titleNm,titleArti))


         }

      }
      cursor?.close()
      val recyclerViewListAdapter = view.findViewById<RecyclerView>(R.id.recycler_view)
      var search_list= arrayListOf<MyItems>()
      var search_view= view.findViewById<SearchView>(R.id.searchView)
      search_view.clearFocus()
      search_view.setOnQueryTextListener(object :SearchView.OnQueryTextListener{
         override fun onQueryTextSubmit(p0: String?): Boolean {
            search_view.clearFocus()
            return true
         }

         override fun onQueryTextChange(newText: String?): Boolean {
            search_list.clear()
            val searchText=newText!!.toLowerCase(Locale.getDefault())
            if (searchText.isNotEmpty()) {
                  dataList.forEach{
                     if(it.title.toLowerCase(Locale.getDefault()).contains(searchText)){
                        search_list.add(it)
                     }
                  }
               recyclerViewListAdapter?.adapter!!.notifyDataSetChanged()
            }
            else {
               search_list.clear();
               search_list.addAll(dataList)
               recyclerViewListAdapter?.adapter!!.notifyDataSetChanged()
            }
            return false
         }
      })
      if(recyclerViewListAdapter!=null) {
         search_list.addAll(dataList)
         val myadapter=Music_Adapter(search_list)
         recyclerViewListAdapter.adapter=myadapter
         myadapter.setOnItemClickListener(object :Music_Adapter.onItemClickListener{
            override fun onItemClick(position: Int) {
                     var i1=Intent(view.context, music_player::class.java)
               var path = "";
                     CoroutineScope(Dispatchers.Main).launch {
                         path= server.findSongPathByTitle(musicList[position]).toString()
                        i1.putExtra("path",path)
                     }

                     Toast.makeText(view.context,path,Toast.LENGTH_SHORT).show()
                     startActivity(i1);

            }
         })
         recyclerViewListAdapter.layoutManager=LinearLayoutManager(activity)
      }
      return view
   }
}

