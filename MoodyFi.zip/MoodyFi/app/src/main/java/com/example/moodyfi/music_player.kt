package com.example.moodyfi


import android.media.MediaPlayer
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.SystemClock
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ImageSpan
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class music_player : AppCompatActivity() {

    var playOrPause:Boolean =false
    lateinit var  play_pause_btn :Button
    lateinit var mp:MediaPlayer
    lateinit var t1: TextView
    private var isRunning: Boolean=false
    private var startTime: Long = 0
    private var elapsedTime: Long = 0
    private val handler = Handler()

    private fun createMp(str :String) {
        mp= MediaPlayer()
        mp.setDataSource(str)
    }
    private fun updatePlayPauseButton() {                   //To change the icon of play pause
        if(playOrPause) {

            val icon = resources.getDrawable(R.drawable.play_icon, null)
            icon.setBounds(0, 0, icon.intrinsicWidth, icon.intrinsicHeight)
            val spannableString = SpannableString(" ")
            val imageSpan = ImageSpan(icon, ImageSpan.ALIGN_BASELINE)
            spannableString.setSpan(imageSpan, 0, 1, Spannable.SPAN_INCLUSIVE_EXCLUSIVE)
          //  play_pause_btn.text = spannableString
            playOrPause =false
        }

        else {
            val icon = resources.getDrawable(R.drawable.pause_icon, null)
            icon.setBounds(0, 0, icon.intrinsicWidth, icon.intrinsicHeight)
            val spannableString = SpannableString(" ")
            val imageSpan = ImageSpan(icon, ImageSpan.ALIGN_BASELINE)
            spannableString.setSpan(imageSpan, 0, 1, Spannable.SPAN_INCLUSIVE_EXCLUSIVE)
         //   play_pause_btn.text = spannableString
            playOrPause =true
        }
    }
    private fun miliToMin(milS:Int):String
    {
        val min=milS/60000
        val sec=(milS%60000) /1000

        if(min==0)
            return String.format("%02d",sec)
        return String.format("%02d:%02d",min,sec);
    }
    private val stopwatchRunnable = object : Runnable {
        override fun run() {
            elapsedTime = SystemClock.elapsedRealtime() - startTime
            updateElapsedTime()
            handler.postDelayed(this, 1000) // Update every second
        }
    }
    private fun updateElapsedTime() {
        val hours = (elapsedTime / 3600000).toInt()
        val minutes = ((elapsedTime - hours * 3600000) / 60000).toInt()
        val seconds = ((elapsedTime - hours * 3600000 - minutes * 60000) / 1000).toInt()
        val timeString = String.format("%02d:%02d", minutes, seconds)
        t1.text = timeString
    }
    private fun updateSongTime()
    {
        t1=findViewById(R.id.t1)
        if(!isRunning)
        {
            isRunning=true
            startTime = SystemClock.elapsedRealtime() - elapsedTime
            handler.post(stopwatchRunnable)

        }
    }
    private fun updateSeeker(seekBar: SeekBar)
    {
        Thread(Runnable {
            while (mp.isPlaying) {

                seekBar.progress = mp.currentPosition

                try {
                    Thread.sleep(1000)
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                }

            }
        }).start()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music_player)
       var play_pause_btn=findViewById<Button>(R.id.play_pause_btn)
        var str=intent.getStringExtra("path");
        if(str==null) {
            return
        }

        Toast.makeText(this,"404",Toast.LENGTH_SHORT).show()
        var flag=0;
        var music_start_time=findViewById<TextView>(R.id.music_start_time)
        var music_end_time=findViewById<TextView>(R.id.music_end_time)
        var seekBar=findViewById<SeekBar>(R.id.seekId)
        music_end_time.text=miliToMin(mp.duration)
        seekBar.setOnSeekBarChangeListener(object :SeekBar.OnSeekBarChangeListener
        {
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                if(p2)
                {
                    mp.seekTo(p1)
                    t1.setText(miliToMin(p1))
                }
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {
                mp.pause()
            }

            override fun onStopTrackingTouch(p0: SeekBar?) {
                mp.start()
                updateSeeker(seekBar)
                t1.setText("0.0")
            }

        })



        val icon = resources.getDrawable(R.drawable.play_icon, null) // temproray sathi pause icon ahe
        icon.setBounds(0, 0, icon.intrinsicWidth, icon.intrinsicHeight)
        val spannableString = SpannableString(" ")
        val imageSpan = ImageSpan(icon, ImageSpan.ALIGN_BASELINE)
        spannableString.setSpan(imageSpan, 0, 1, Spannable.SPAN_INCLUSIVE_EXCLUSIVE)
        play_pause_btn.text = spannableString
        playOrPause =false

        mp= MediaPlayer()
        mp.setDataSource(str)
        seekBar.max=mp.duration

        play_pause_btn.setOnClickListener {
            updatePlayPauseButton()
            if(playOrPause) {
                if(flag==1)
                {
                    createMp(str)
                    flag=0
                }

                mp.start()
                updateSeeker(seekBar)
                updateSongTime()
            }
            else {
                mp.pause()
                isRunning = false
                handler.removeCallbacks(stopwatchRunnable)
            }
        }




    }
}